package com.hollowburst.network;

import com.hollowburst.CutsceneType;
import com.hollowburst.client.ClientHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Server -> client: start a cutscene. */
public class CutscenePacket {
    public final int typeId;

    public CutscenePacket(CutsceneType type) {
        this.typeId = type.id;
    }

    private CutscenePacket(int typeId) {
        this.typeId = typeId;
    }

    public static void encode(CutscenePacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.typeId);
    }

    public static CutscenePacket decode(FriendlyByteBuf buf) {
        return new CutscenePacket(buf.readVarInt());
    }

    public static void handle(CutscenePacket msg, CustomPayloadEvent.Context ctx) {
        // Only ever runs on the client (PLAY_TO_CLIENT). ClientHandler is a client-only class.
        ClientHandler.startCutscene(CutsceneType.fromId(msg.typeId));
    }
}
