package com.hollowburst.client;

import com.hollowburst.CutsceneType;

/** Client-only entry point called by the cutscene packet. */
public final class ClientHandler {

    public static void startCutscene(CutsceneType type) {
        CutscenePlayer.start(CutsceneDefs.get(type));
    }

    private ClientHandler() {}
}
