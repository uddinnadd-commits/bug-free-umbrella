package com.hollowburst.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;

import java.util.Random;

/** Raw triangle drawing used for the impact frames (speed lines, star burst, inversion). */
final class Gfx {

    /** Draws triangles from a flat array of x,y pairs (6 floats per triangle). */
    static void triangles(GuiGraphics g, float[] v, int rgb, boolean invertBlend) {
        if (v.length < 6) return;
        g.flush();
        Matrix4f m = g.pose().last().pose();
        int r = (rgb >> 16) & 255;
        int gr = (rgb >> 8) & 255;
        int b = rgb & 255;

        RenderSystem.enableBlend();
        if (invertBlend) {
            RenderSystem.blendFunc(GlStateManager.SourceFactor.ONE_MINUS_DST_COLOR, GlStateManager.DestFactor.ZERO);
        } else {
            RenderSystem.defaultBlendFunc();
        }
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder buf = Tesselator.getInstance().begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_COLOR);
        for (int i = 0; i + 5 < v.length; i += 6) {
            buf.addVertex(m, v[i], v[i + 1], 0.0F).setColor(r, gr, b, 255);
            buf.addVertex(m, v[i + 2], v[i + 3], 0.0F).setColor(r, gr, b, 255);
            buf.addVertex(m, v[i + 4], v[i + 5], 0.0F).setColor(r, gr, b, 255);
        }
        BufferUploader.drawWithShader(buf.buildOrThrow());

        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
    }

    /** Inverts every colour already on screen. */
    static void invert(GuiGraphics g, int w, int h) {
        triangles(g, new float[] { 0, 0, w, 0, w, h, 0, 0, w, h, 0, h }, 0xFFFFFF, true);
    }

    /** Thin wedges that converge on the middle of the screen, like manga focus lines. */
    static void speedLines(GuiGraphics g, int w, int h, long seed, int rgb, int count) {
        Random rnd = new Random(seed);
        float cx = w / 2.0F;
        float cy = h / 2.0F;
        double far = Math.hypot(w, h);
        float[] v = new float[count * 6];
        for (int i = 0; i < count; i++) {
            double a = rnd.nextDouble() * Math.PI * 2.0;
            double da = 0.004 + rnd.nextDouble() * 0.03;
            double inner = far * (0.08 + rnd.nextDouble() * 0.40);
            int o = i * 6;
            v[o] = cx + (float) (Math.cos(a - da) * far);
            v[o + 1] = cy + (float) (Math.sin(a - da) * far);
            v[o + 2] = cx + (float) (Math.cos(a + da) * far);
            v[o + 3] = cy + (float) (Math.sin(a + da) * far);
            v[o + 4] = cx + (float) (Math.cos(a) * inner);
            v[o + 5] = cy + (float) (Math.sin(a) * inner);
        }
        triangles(g, v, rgb, false);
    }

    /** A jagged explosion star in the middle of the screen. */
    static void starBurst(GuiGraphics g, int w, int h, long seed, int rgb) {
        Random rnd = new Random(seed * 31L + 7L);
        float cx = w / 2.0F;
        float cy = h / 2.0F;
        int spikes = 14 + rnd.nextInt(6);
        int pts = spikes * 2;
        float[] px = new float[pts];
        float[] py = new float[pts];
        for (int k = 0; k < pts; k++) {
            double a = (Math.PI * 2.0 * k) / pts + rnd.nextDouble() * 0.08;
            double outer = h * (0.20 + rnd.nextDouble() * 0.30);
            double rad = (k % 2 == 0) ? outer : outer * 0.38;
            px[k] = cx + (float) (Math.cos(a) * rad);
            py[k] = cy + (float) (Math.sin(a) * rad);
        }
        float[] v = new float[pts * 6];
        for (int k = 0; k < pts; k++) {
            int n = (k + 1) % pts;
            int o = k * 6;
            v[o] = cx;
            v[o + 1] = cy;
            v[o + 2] = px[k];
            v[o + 3] = py[k];
            v[o + 4] = px[n];
            v[o + 5] = py[n];
        }
        triangles(g, v, rgb, false);
    }

    private Gfx() {}
}
