package com.hollowburst.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Draws letterbox bars, tint, flashes, subtitles and impact frames over the HUD. */
final class CutsceneRenderer {

    private static final long BARS_IN_MS = 350;
    private static final long BARS_OUT_MS = 400;

    static void render(GuiGraphics g) {
        CutsceneDef def = CutscenePlayer.def();
        if (def == null) return;

        Minecraft mc = Minecraft.getInstance();
        long t = CutscenePlayer.elapsedMs();
        if (t >= def.durationMs) return;

        int w = g.guiWidth();
        int h = g.guiHeight();

        drawTint(g, def, t, w, h);
        drawFlashes(g, def, t, w, h);
        int barH = drawLetterbox(g, def, t, w, h);
        drawSubtitle(g, mc.font, def, t, w, h, barH);
        drawImpact(g, def, t, w, h);
    }

    // ------------------------------------------------------------------ tint and flashes

    private static void drawTint(GuiGraphics g, CutsceneDef def, long t, int w, int h) {
        double a = Curves.clamp01(def.tintAlpha.applyAsDouble(t));
        int alpha = (int) (a * 255.0);
        if (alpha < 4) return;
        g.fill(0, 0, w, h, (alpha << 24) | (def.tintRgb & 0xFFFFFF));
    }

    private static void drawFlashes(GuiGraphics g, CutsceneDef def, long t, int w, int h) {
        for (CutsceneDef.Flash f : def.flashes) {
            if (t < f.at() || t >= f.at() + f.duration()) continue;
            double x = 1.0 - (double) (t - f.at()) / (double) f.duration();
            int alpha = (int) (255.0 * x * x);
            if (alpha < 4) continue;
            g.fill(0, 0, w, h, (alpha << 24) | (f.rgb() & 0xFFFFFF));
        }
    }

    // ------------------------------------------------------------------ letterbox

    /** Returns the current bar height in GUI pixels. */
    private static int drawLetterbox(GuiGraphics g, CutsceneDef def, long t, int w, int h) {
        double in = Curves.smooth((double) t / BARS_IN_MS);
        double out = Curves.smooth((double) (def.durationMs - t) / BARS_OUT_MS);
        double p = Math.min(in, out);
        int barH = (int) (h * 0.125 * p);
        if (barH > 0) {
            g.fill(0, 0, w, barH, 0xFF000000);
            g.fill(0, h - barH, w, h, 0xFF000000);
        }
        return barH;
    }

    // ------------------------------------------------------------------ subtitles

    private static void drawSubtitle(GuiGraphics g, Font font, CutsceneDef def, long t, int w, int h, int barH) {
        CutsceneDef.Sub active = null;
        for (CutsceneDef.Sub s : def.subs) {
            if (t >= s.start() && t < s.end()) active = s; // the latest started line wins
        }
        if (active == null || barH < 4) return;

        double fadeIn = Curves.clamp01((t - active.start()) / 120.0);
        double fadeOut = Curves.clamp01((active.end() - t) / 250.0);
        int alpha = (int) (255.0 * Math.min(fadeIn, fadeOut));
        if (alpha < 8) return;

        String full = I18n.get(active.langKey());
        int shown = (int) Math.min(full.length(), (t - active.start()) * 0.05); // 50 characters per second
        if (shown <= 0) return;

        float scale = active.scale();
        int maxWidth = (int) (w * 0.80 / scale);
        List<String> lines = wrap(font, full, maxWidth, active.bold());

        int lineH = 10;
        float total = lines.size() * lineH * scale;
        float y0 = h - barH / 2.0F - total / 2.0F;
        int color = (alpha << 24) | (active.rgb() & 0xFFFFFF);

        g.pose().pushPose();
        g.pose().translate(w / 2.0F, y0, 0.0F);
        g.pose().scale(scale, scale, 1.0F);

        int remaining = shown;
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            if (remaining <= 0) break;
            String part = line.length() <= remaining ? line : line.substring(0, remaining);
            remaining -= line.length() + 1;

            Component full1 = styled(line, active.bold());
            Component part1 = styled(part, active.bold());
            int x = -font.width(full1) / 2; // centre on the full line so the text does not jitter
            g.drawString(font, part1, x, i * lineH, color, true);
        }
        g.pose().popPose();
    }

    private static Component styled(String s, boolean bold) {
        Component c = Component.literal(s);
        return bold ? Component.literal(s).withStyle(ChatFormatting.BOLD) : c;
    }

    private static List<String> wrap(Font font, String text, int maxWidth, boolean bold) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String candidate = line.length() == 0 ? word : line + " " + word;
            if (line.length() > 0 && font.width(styled(candidate, bold)) > maxWidth) {
                out.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(candidate);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    // ------------------------------------------------------------------ impact frames

    private static void drawImpact(GuiGraphics g, CutsceneDef def, long t, int w, int h) {
        for (CutsceneDef.Impact im : def.impacts) {
            long len = (long) im.frames().length * im.frameMs();
            if (t < im.at() || t >= im.at() + len) continue;

            int idx = (int) ((t - im.at()) / im.frameMs());
            int style = im.frames()[idx];
            long seed = im.seed() + idx * 7919L;

            switch (style) {
                case CutsceneDef.WHITE -> {
                    g.fill(0, 0, w, h, 0xFFFFFFFF);
                    Gfx.speedLines(g, w, h, seed, 0x000000, 110);
                    Gfx.starBurst(g, w, h, seed, 0x000000);
                }
                case CutsceneDef.BLACK -> {
                    g.fill(0, 0, w, h, 0xFF000000);
                    Gfx.speedLines(g, w, h, seed, 0xFFFFFF, 110);
                    Gfx.starBurst(g, w, h, seed, 0xFFFFFF);
                }
                default -> {
                    Gfx.invert(g, w, h);
                    Gfx.speedLines(g, w, h, seed, 0x000000, 70);
                    Gfx.starBurst(g, w, h, seed, 0xFFFFFF);
                }
            }
            return; // one impact frame at a time
        }
    }

    private CutsceneRenderer() {}
}
