package com.hollowburst.client;

import com.hollowburst.HollowBurstMod;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.event.AddGuiOverlayLayersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = HollowBurstMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(ClientKeys.ACTIVATE);
    }

    /**
     * Forge 1.20.5+ removed RenderGuiEvent. HUD drawing now goes through a layer;
     * adding ours last puts it on top of every vanilla layer.
     */
    @SubscribeEvent
    public static void onAddGuiLayers(AddGuiOverlayLayersEvent event) {
        event.getLayeredDraw().add(
                ResourceLocation.fromNamespaceAndPath(HollowBurstMod.MODID, "cutscene"),
                (graphics, deltaTracker) -> CutsceneRenderer.render(graphics));
    }

    private ClientModEvents() {}
}
