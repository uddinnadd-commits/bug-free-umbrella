package com.hollowburst;

import com.hollowburst.network.Net;
import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(HollowBurstMod.MODID)
public class HollowBurstMod {
    public static final String MODID = "hollowburst";
    public static final Logger LOGGER = LogUtils.getLogger();

    public HollowBurstMod(FMLJavaModLoadingContext context) {
        context.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        Net.init();
        // Server logic (AbilityManager) and client logic (ClientForgeEvents / ClientModEvents)
        // register themselves through @Mod.EventBusSubscriber.
    }
}
